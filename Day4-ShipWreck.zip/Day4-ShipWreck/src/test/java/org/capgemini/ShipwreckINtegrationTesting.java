package org.capgemini;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;
import org.capgemini.*;
import org.capgemini.model.Shipwreck;
import org.capgemini.repository.ShipwreckRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(Application.class)
public class ShipwreckINtegrationTesting {

	@Autowired
	private ShipwreckRepository shipwreckRepository;
	
	@Test
	public void testFindAll(){
		List<Shipwreck> shipwrecks=shipwreckRepository.findAll();
		assertThat(shipwrecks.size(), is(greaterThanOrEqualTo(0)));
	}
}
