package org.capgemini;

import static org.junit.Assert.*;

import org.capgemini.controller.ShipwreckController;
import org.capgemini.model.Shipwreck;
import org.capgemini.repository.ShipwreckRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;



public class ShipWreckControllerTEst {

	@InjectMocks
	private ShipwreckController sc;
	
	@Mock
	private ShipwreckRepository shipWreckRepo; 
	
	@Before
	public void before(){
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	public void test() {
		
		Shipwreck shipwreck=new Shipwreck();
		shipwreck.setId(1L);
		
		when(shipWreckRepo.findOne(1L)).thenReturn(shipwreck);
		
		Shipwreck shipwreck2=sc.get(1L);
		
		verify(shipWreckRepo).findOne(1L);
		
		assertEquals(1L,shipwreck2.getId().longValue());
		
		//assertThat(shipwreck2.getId(), is(1L));
		
	}

}
