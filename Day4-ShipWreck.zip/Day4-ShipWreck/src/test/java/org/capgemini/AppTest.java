package org.capgemini;

import static org.junit.Assert.*;

import org.capgemini.controller.HomeController;
import org.junit.Test;

public class AppTest {

	@Test
	public void test() {
		HomeController obj=new HomeController();
		String result=obj.sayHello();
		assertEquals(result, "Hello World!");
	}

}
