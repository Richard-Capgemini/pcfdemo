package org.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.capgemini.model.Shipwreck;

public interface ShipwreckRepository extends JpaRepository<Shipwreck, Long> {

}